/*
 * Scrivere un programma Java che permetta ad un utente di inserire i coefficienti a, b e c di
 * un’equazione di secondo grado e che fornisca i valori delle radici.
 * Controllare che l’utente inserisca valori accettabili.
 * Commentare e indentare opportunamente il codice.
 * Dare nomi significativi alle variabili.
 */
// Autore: Nicolò Pierro
// Data: 16/10/2019

import java.util.Scanner;
import java.lang.Math;

public class Main {

    public static void main(String[] args) {
        
        // dichiarazione delle variabili
	    int a, b, c;
	    double delta = 0, x1, x2;
	    // input dei dati
	    Scanner tastiera = new Scanner(System.in);
	    System.out.println("Inserire il coefficiente a");
	    a = tastiera.nextInt();
	    System.out.println("Inserire il coefficiente b");
	    b = tastiera.nextInt();
	    System.out.println("Inserire il coefficiente c");
	    c = tastiera.nextInt();
	    // controllo delle variabili
	    if (a != 0) {
	        // se il controllo è positivo
	        // elaborazione dei dati
	        delta = ((b * b) - 4 * a * c);
	        x1 = (-b + Math.sqrt(delta)) / (2 * a);
	        x2=(-b + Math.sqrt(delta)) / (2 * a);
	        System.out.println("Le due soluzioni sono " + x1 + " e " + x2);
        } else {
            System.out.println("Il coefficiente a deve essere diverso da zero");
        }
        if (delta < 0) {
            System.out.println("L'equazione è impossibile");
        }

        tastiera.close();
    }
}