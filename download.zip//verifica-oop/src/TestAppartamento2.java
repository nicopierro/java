// creare oggetto appartamento senza valore agli attributi
// inserire cf, rc  inseriti dall'utente
// aliquota sempre uguale a 0,20 (quest'anno in questo Comune)
// modificare i valori con quelli appena inseriti
// calcolare TASI e visualizzare il risultato
// Autore: Nicolò Pierro
// Data: 11/11/2019

import java.util.Scanner;
public class TestAppartamento2 {
    public static void main(String[] args) {
        String codicefiscale = " ";
        double renditacatastale = 0;
        
        Appartamento a1 = new Appartamento(codicefiscale, renditacatastale);
        
        Scanner tastiera = new Scanner(System.in);
        System.out.println("Inserire il proprio codice fiscale:");
        codicefiscale = tastiera.nextLine();
        System.out.println("Inserire la propria rendita catastale:");
        renditacatastale = tastiera.nextDouble();
        a1.setCodiceFiscale(codicefiscale);
        a1.setRenditaCatastale(renditacatastale);
        System.out.println("Caro/a sig./sig.ra " + a1.getCodiceFiscale() + ", l'importo della TASI del suo appartamento è " + a1.getTasi(0.20));
        
        tastiera.close();
    }

}
