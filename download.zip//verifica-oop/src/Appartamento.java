// classe Appartamento
// attributi codicefiscale, renditacatastale
// costruttori uno vuoto e uno con tutto
// metodi getCodiceFiscale(), getRenditaCatastale(), setRenditaCatastale(), setCodiceFiscale(), getTasi()
// Autore: Nicolò Pierro
// Data: 11/11/2019

public class Appartamento {
    private String codicefiscale;
    private double renditacatastale;
    
    public Appartamento() {
        codicefiscale = "################";
        renditacatastale = 1.0;
        
    }
    
    public Appartamento(String cf, double rc) {
        codicefiscale = cf;
        renditacatastale = rc;
    }
    
    public String getCodiceFiscale() {
        return codicefiscale;
    }
    
    public double getRenditaCatastale() {
        return renditacatastale;        
    }
    
    public double getTasi(double a) {
        double aliquota = a;
        double TASI = (renditacatastale + renditacatastale * 5 / 100) * 160 * aliquota;
        return TASI;
    }
    
    public void setRenditaCatastale(double rc) {
        renditacatastale = rc;
    }
    
    public void setCodiceFiscale(String cf) {
        codicefiscale = cf;
    }
    
    
}
