// Modificare TestAppartamento2 per controllare i valori inseriti
// Autore: Nicolò Pierro
// Data: 11/11/2019

import java.util.Scanner;
public class TestAppartamento3 {
    public static void main(String[] args) {
        String codicefiscale = " ";
        double renditacatastale = 0;
        
        Appartamento a1 = new Appartamento(codicefiscale, renditacatastale);
        
        Scanner tastiera = new Scanner(System.in);
        System.out.println("Inserire il proprio codice fiscale:");
        codicefiscale = tastiera.nextLine();
        if (codicefiscale.length() != 16) {
            System.out.println("Attenzione, il codice fiscale  delle persone fisiche è composto da 16 caratteri alfanumerici");
        }
        
        System.out.println("Inserire la propria rendita catastale:");
        renditacatastale = tastiera.nextDouble();
        if (renditacatastale <= 0) {
            System.out.println("La rendita catastale deve essere maggiore di 0");
        }
        
        if (codicefiscale.length() == 16 && renditacatastale >= 0) {
        a1.setCodiceFiscale(codicefiscale);
        a1.setRenditaCatastale(renditacatastale);
        System.out.println("Caro/a sig./sig.ra " + a1.getCodiceFiscale() + ", l'importo della TASI del suo appartamento è " + a1.getTasi(0.20));
        } else {
            System.out.println("Non è stato possibile calcolare il valore della TASI perché non tutti i valori inseriti sono validi.");
        }
        
        tastiera.close();
    }

}
