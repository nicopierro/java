// Appartamento con renditacatastale = 343,55 del Sig. CFTTRF76E12E456S
// Aliquota 0,20
// Calcolare TASI e visualizzare risultato
// Autore: Nicolò Pierro
// Data: 11/11/2019

public class TestAppartamento1 {
    public static void main(String[] args) {
        
        Appartamento a1 = new Appartamento("CFTTRF76E12E456S", 343.55);
        
        System.out.println("Caro/a sig./sig.ra " + a1.getCodiceFiscale() + ", l'importo della TASI del suo appartamento è " + a1.getTasi(0.20));
    }

}
