
public class Interruttore {
}
