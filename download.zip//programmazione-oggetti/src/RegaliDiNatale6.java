
public class RegaliDiNatale6 {
}
