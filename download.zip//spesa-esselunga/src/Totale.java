
public class Totale {
}
